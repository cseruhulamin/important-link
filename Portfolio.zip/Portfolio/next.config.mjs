const nextConfig = {
  images: {
    domains: ["i.pinimg.com"],
  },
};

export default nextConfig;
